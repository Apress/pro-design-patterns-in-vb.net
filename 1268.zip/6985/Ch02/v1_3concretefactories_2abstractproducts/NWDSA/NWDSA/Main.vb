Module Main
    Public g_ConnStrings As NWDSAConnStrings
End Module
