When you open MVCPresTier.sln, you will be prompted for information 
about the web access mode for the application NOPWeb. 

BEFORE opening the solution, you should
(a) Copy the \NOPWeb folder (and its contents) to a folder 
    under your machine's IIS root (this is usually c:\inetpub\wwwroot)
(b) Use Internet Service Manager to turn c:\inetpub\wwwroot\NOPWeb 
    into a Web Applciation 

Then the solution should open successfully. 
